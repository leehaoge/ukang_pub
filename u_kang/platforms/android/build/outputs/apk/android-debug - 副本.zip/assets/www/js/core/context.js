define([], function() {
    var contexts = {

    };

    return contexts;
});